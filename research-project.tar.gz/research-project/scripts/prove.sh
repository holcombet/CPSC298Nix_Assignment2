#!/bin/bash

echo "Attempting to prove theorem..."

sleep 1

echo "Searching for counterexample..."
sleep 1

echo "No counterexample found."
sleep 1

echo
echo "Conclusion:"
echo "Probably true."

