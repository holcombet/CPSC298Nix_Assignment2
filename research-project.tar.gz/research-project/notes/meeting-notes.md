# Research Meeting Notes

## September 12
* Discussed the direction of the project.
* Interested in the intersection of mathematics and computer science.
* Talked about using formal methods to check mathematical arguments.
* Need to narrow down the scope of the project.
## Septemer 19
* Reviewed progress from past week
* Some examples are working, but a few need more investigationg
* Discuessed how much mathematical background to include
* Talked about trying a few simplr examples first

## September 26
* Went over latest results
* Discussed keeping experimental work separate from main project
* need to make experiments easier to produce
* repository is getting a little messy

